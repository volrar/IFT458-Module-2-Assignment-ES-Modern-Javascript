
const obj1 = {
    id: 1,
    customerName: 'Logan Rupp',
    phoneNumber: 951-529-4903,
    address: {
            street: '6862 W. Canterbury Dr.',
            city: 'Peoria',
            state: 'Arizona',
            zipcode: 85345,
        },
    loanAmount: 8000,
    interest: 0.06,
    loanTermYears: 4,
    loanType: 'auto loan',
    description: '2015 Ford Fiesta St',
    calculatedLoanAmount: function() {//insert working loan calculator here.
        let sum = 1 + 1;
        return sum;
    }
};

const obj2 = {
    id: 2,
    customerName: 'Joseph Rupp',
    phoneNumber: 951-533-8259,
    address: {
            street: '6862 W. Canterbury Dr.',
            city: 'Peoria',
            state: 'Arizona',
            zipcode: 85345,
        },
    loanAmount: 8000,
    interest: 0.06,
    loanTermYears: 4,
    loanType: 'auto loan',
    description: '2018 Ford F-150',
    calculatedLoanAmount: function() {//insert working loan calculator here.
        let sum = 1 + 1;
        return sum;
    }
};

const obj3 = {
    id: 3,
    customerName: 'Sheri Rupp',
    phoneNumber: 951-533-8236,
    address: {
            street: '6862 W. Canterbury Dr.',
            city: 'Peoria',
            state: 'Arizona',
            zipcode: 85345,
        },
    loanAmount: 8000,
    interest: 0.06,
    loanTermYears: 4,
    loanType: 'auto loan',
    description: '2015 Lexus is200t',
    calculatedLoanAmount: function() {//insert working loan calculator here.
        let sum = 1 + 1;
        return sum;
    }
};

const obj4 = {
    id: 4,
    customerName: 'Tyler Rupp',
    phoneNumber: 951-533-5607,
    address: {
            street: '6862 W. Canterbury Dr.',
            city: 'Peoria',
            state: 'Arizona',
            zipcode: 85345,
        },
    loanAmount: 8000,
    interest: 0.06,
    loanTermYears: 4,
    loanType: 'auto loan',
    description: '2009 Honda Fit S',
    calculatedLoanAmount: function() {//insert working loan calculator here.
        let sum = 1 + 1;
        return sum;
    }
};

const obj5 = {
    id: 5,
    customerName: 'Veronica Escelara',
    phoneNumber: 608-432-9781,
    address: {
            street: '6862 W. Canterbury Dr.',
            city: 'Peoria',
            state: 'Arizona',
            zipcode: 85345,
        },
    loanAmount: 8000,
    interest: 0.06,
    loanTermYears: 4,
    loanType: 'auto loan',
    description: '2014 Ford Focus Se',
    calculatedLoanAmount: function() {//insert working loan calculator here.
        let sum = 1 + 1;
        return sum;
    }
};

const objects = [obj1, obj2, obj3, obj4, obj5];//declares new objects array

const loanAmounts = [];//declares new loanAmounts array.

for(loan in objects) { //loops through objects array and pushes each calculatedLoanAmount to the new loanAmounts array
    loanAmounts.push(objects[loan].calculatedLoanAmount());
};

console.log(loanAmounts);